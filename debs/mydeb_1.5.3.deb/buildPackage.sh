#!/bin/bash

path="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
value=$(/usr/libexec/PlistBuddy -c 'Print :CFBundleShortVersionString' ${path}/Applications/LHDPScopeHelper.app/info.plist)
echo $value
# value=1.4.4

cat ./DEBIAN/control|while read line
do 
    if [[ $line == "Version"* ]]; then
        echo Version: $value >> ./temp.txt
    else
        echo $line >> ./temp.txt
    fi
done


: > ./DEBIAN/control

cat ./temp.txt|while read line
do 
    if [[ $line == "Version"* ]]; then
        echo Version: $value >> ./DEBIAN/control

    elif [[ $line == "Package"* ]]; then
        echo  Package: com.xinfeng.dphelper$value >> ./DEBIAN/control

    elif [[ $line == "Name"* ]]; then
        echo  Name: 点评助手$value >> ./DEBIAN/control
        
    else
        echo $line >> ./DEBIAN/control
    fi
done

rm -f ./temp.txt

cp -f ./Applications/LHDPScopeHelper.app/LHDPScopeHelper ./LHDPScopeHelper
ldid -Smy.entitlements LHDPScopeHelper
cp -f ./LHDPScopeHelper ./Applications/LHDPScopeHelper.app/LHDPScopeHelper
find . -name '*.DS_Store' -type f -delete
rm -f mydeb_*
dpkg-deb -b ./ mydeb_$value.deb


